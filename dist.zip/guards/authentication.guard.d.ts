import { CanActivate, ExecutionContext } from '@nestjs/common';
export declare class AuthenticationGuard implements CanActivate {
    private logger;
    canActivate(context: ExecutionContext): boolean;
}
