export declare class MerchantsModule {
}
