export declare class UssdModule {
}
