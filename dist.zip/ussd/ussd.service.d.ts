export declare class UssdService {
}
