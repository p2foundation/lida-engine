import { Response } from "express";
export declare class UssdController {
    private logger;
    primaryCallback(res: Response, qr: any): Promise<any>;
    callbackResponse(res: Response, mdata: any): Promise<any>;
}
