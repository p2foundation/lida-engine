export declare class BillpaymentsModule {
}
