export declare class EtranzactModule {
}
