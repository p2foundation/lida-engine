export declare class PayswitchModule {
}
