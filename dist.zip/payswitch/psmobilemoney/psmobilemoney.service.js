"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PsmobilemoneyService = void 0;
const axios_1 = require("@nestjs/axios");
const common_1 = require("@nestjs/common");
const operators_1 = require("rxjs/operators");
const https = require("https");
const utils_1 = require("../../utilities/utils");
const constants_1 = require("../../constants");
let PsmobilemoneyService = class PsmobilemoneyService {
    constructor(httpService) {
        this.httpService = httpService;
        this.logger = new common_1.Logger('PsmobilemoneyService');
    }
    primaryCallbackUrl() {
    }
    transferMobilemoney(transDto) {
        const { description, recipientMsisdn, amount, transType, channel } = transDto;
        const tmParams = {
            amount: amount || '',
            processing_code: constants_1.PROCESSING_CODE_SEND,
            transaction_id: (0, utils_1.generateTransactionId)() || '',
            desc: description,
            merchant_id: constants_1.PAYSWITCH_MERCHANTID,
            subscriber_number: recipientMsisdn,
            'r-switch': channel,
        };
        const base64_encode = (0, utils_1.generateMerchantKey)();
        const configs = {
            url: 'https://prod.theteller.net/v1.1/transaction/process',
            body: tmParams,
            headers: {
                Authorization: `Basic ${base64_encode}`,
            },
            agent: new https.Agent({
                rejectUnauthorized: false,
            }),
        };
        this.logger.log(`TRANSFER MOBILE MONEY payload config == ${JSON.stringify(configs)}`);
        return this.httpService
            .post(configs.url, configs.body, {
            headers: configs.headers,
            httpsAgent: configs.agent,
        })
            .pipe((0, operators_1.map)((tmRes) => {
            this.logger.verbose(`TRANSFER MOBILE MONEY server response => ${JSON.stringify(tmRes.data)}`);
            return tmRes.data;
        }), (0, operators_1.catchError)((Sm2Error) => {
            this.logger.error(`ERROR TRANSFER MOBILE MONEY => ${Sm2Error.data}`);
            return Sm2Error.data;
        }));
    }
    mobilemoneyPayment(transDto) {
        const { customerMsisdn, amount, processingCode, description, channel } = transDto;
        const localTansId = (0, utils_1.generateTransactionIdPayswitch)();
        this.logger.log(`local transaction id ==> ${localTansId}`);
        const mpParams = {
            "amount": amount || '',
            "processing_code": constants_1.PROCESSING_CODE_DEBIT || processingCode,
            "transaction_id": localTansId,
            "desc": description || 'Lidapay mobile money debit ',
            "merchant_id": constants_1.PAYSWITCH_MERCHANTID,
            "subscriber_number": customerMsisdn || '',
            "r-switch": channel
        };
        const base64_encode = (0, utils_1.generateMerchantKey)();
        const configs = {
            url: constants_1.PAYSWTICH_PROD_BASEURL + '/v1.1/transaction/process',
            body: mpParams,
            headers: {
                Authorization: `Basic ${base64_encode}`,
            },
            agent: new https.Agent({
                rejectUnauthorized: false,
            }),
        };
        this.logger.log(`RECEIVE MONEY payload config == ${JSON.stringify(configs)}`);
        return this.httpService
            .post(configs.url, configs.body, {
            httpsAgent: configs.agent,
            headers: configs.headers
        })
            .pipe((0, operators_1.map)((mpRes) => {
            this.logger.log(`RECEIVE MONEY server response => ${JSON.stringify(mpRes.data)}`);
            return mpRes.data;
        }), (0, operators_1.catchError)((mpError) => {
            this.logger.error(`ERROR DEBIT WALLET => ${JSON.stringify(mpError.data)}`);
            return mpError.data;
        }));
    }
};
PsmobilemoneyService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [axios_1.HttpService])
], PsmobilemoneyService);
exports.PsmobilemoneyService = PsmobilemoneyService;
//# sourceMappingURL=psmobilemoney.service.js.map