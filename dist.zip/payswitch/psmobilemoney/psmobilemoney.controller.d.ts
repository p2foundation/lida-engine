import { PsmobilemoneyService } from './psmobilemoney.service';
import { Response } from 'express';
import { TransferMobileMoneyDto } from './dto/transfer.mobilemoney.dto';
import { PayMobileMoneyDto } from './dto/pay.mobilemoney.dto';
export declare class PsmobilemoneyController {
    private psMobilemoneyService;
    constructor(psMobilemoneyService: PsmobilemoneyService);
    creditWallet(transDto: TransferMobileMoneyDto): Promise<import("rxjs").Observable<import("axios").AxiosResponse<TransferMobileMoneyDto, any>>>;
    debitWallet(transDto: PayMobileMoneyDto, res: Response): Promise<void>;
}
