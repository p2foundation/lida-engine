export declare class PsmobilemoneyModule {
}
