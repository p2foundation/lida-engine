export declare class CallbackDto {
    status: string;
    code: any;
    reason: string;
    r_switch: string;
    subscriber_number: string;
    amount: any;
    channel: string;
    currency: string;
    transaction_id: string;
}
