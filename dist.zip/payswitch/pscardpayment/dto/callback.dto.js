"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CallbackDto = void 0;
class CallbackDto {
}
exports.CallbackDto = CallbackDto;
//# sourceMappingURL=callback.dto.js.map