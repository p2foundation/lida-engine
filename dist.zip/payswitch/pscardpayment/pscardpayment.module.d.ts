export declare class PscardpaymentModule {
}
