"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RETAILER = exports.API_SECRET = exports.API_KEY = exports.ONE4ALL_BASEURL = exports.JWT_SECRET = exports.MONGO_CONNECTION = exports.SERVER_PORT = exports.SERVER_ORIGIN = void 0;
exports.SERVER_ORIGIN = 'http://lidagate-env.eba-i9mqd3un.us-east-2.elasticbeanstalk.com/';
exports.SERVER_PORT = '3000';
exports.MONGO_CONNECTION = 'mongodb+srv://nestjs-admin:BSFGkUY7T0XcJfpI@cluster0-4r2ye.mongodb.net/nestjs-course?retryWrites=true&w=majority';
exports.JWT_SECRET = "vp9eb22K5Sz4";
exports.ONE4ALL_BASEURL = 'https://tppgh.myone4all.com/api';
exports.API_KEY = 'd75ee5a01bac11eca2b1ebf2869d5116';
exports.API_SECRET = '59jKNaflSu';
exports.RETAILER = '233241603241';
//# sourceMappingURL=constants.js.map