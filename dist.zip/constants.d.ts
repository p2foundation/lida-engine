export declare const SERVER_ORIGIN = "http://lidagate-env.eba-i9mqd3un.us-east-2.elasticbeanstalk.com/";
export declare const SERVER_PORT = "3000";
export declare const MONGO_CONNECTION = "mongodb+srv://nestjs-admin:BSFGkUY7T0XcJfpI@cluster0-4r2ye.mongodb.net/nestjs-course?retryWrites=true&w=majority";
export declare const JWT_SECRET = "vp9eb22K5Sz4";
export declare const ONE4ALL_BASEURL = "https://tppgh.myone4all.com/api";
export declare const API_KEY = "d75ee5a01bac11eca2b1ebf2869d5116";
export declare const API_SECRET = "59jKNaflSu";
export declare const RETAILER = "233241603241";
