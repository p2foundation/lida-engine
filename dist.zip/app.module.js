"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const app_controller_1 = require("./app.controller");
const app_service_1 = require("./app.service");
const auth_module_1 = require("./auth/auth.module");
const airtime_module_1 = require("./one4all/airtime/airtime.module");
const merchants_module_1 = require("./merchants/merchants.module");
const billpayments_module_1 = require("./one4all/billpayments/billpayments.module");
const etranzact_module_1 = require("./etranzact/etranzact.module");
const sms_module_1 = require("./one4all/sms/sms.module");
const mobilemoney_module_1 = require("./one4all/mobilemoney/mobilemoney.module");
const psmobilemoney_module_1 = require("./payswitch/psmobilemoney/psmobilemoney.module");
const pscardpayment_module_1 = require("./payswitch/pscardpayment/pscardpayment.module");
let AppModule = class AppModule {
};
AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            auth_module_1.AuthModule,
            airtime_module_1.AirtimeModule,
            merchants_module_1.MerchantsModule,
            billpayments_module_1.BillpaymentsModule,
            etranzact_module_1.EtranzactModule, sms_module_1.SmsModule, mobilemoney_module_1.MobilemoneyModule, psmobilemoney_module_1.PsmobilemoneyModule, pscardpayment_module_1.PscardpaymentModule
        ],
        controllers: [app_controller_1.AppController],
        providers: [app_service_1.AppService],
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map