export declare class PasswordHasherService {
    hashPassword(password: string): Promise<any>;
    comparePasswords(plainText: string, encryptedPassword: string): Promise<boolean>;
}
