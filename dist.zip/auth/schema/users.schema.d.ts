import * as mongoose from 'mongoose';
export declare const UsersSchema: mongoose.Schema<any, mongoose.Model<any, any, any, any, any>, {}, {}, {}, {}, "type", {
    status: string;
    role: "GUEST" | "USER" | "ADMIN" | "DEVELOPER";
    createdAt: Date;
    updatedAt: Date;
    userName?: string;
    firstName?: string;
    lastName?: string;
    email?: string;
    mobile?: string;
    password?: string;
    gravatar?: string;
}>;
