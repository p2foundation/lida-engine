import { Response } from 'express';
import { UserDto } from './dto/user.dto';
import { AuthService } from './auth.service';
import { UserInterface } from './interface/user.interface';
export declare class AuthController {
    private authService;
    private logger;
    constructor(authService: AuthService);
    loginUser(userData: UserDto): Promise<UserInterface>;
    signUpUser(userData: UserDto): Promise<any>;
    getUserById(res: Response, userId: string): Promise<any>;
    findAllEmployees(res: Response): Promise<any>;
    getAllUsers(res: Response): Promise<any>;
    updateUserProfile(res: Response, userId: string, changes: UserDto): Promise<any>;
    deleteUserAccount(userId: string, res: Response): Promise<any>;
    deleteAllUserAccounts(res: Response): Promise<any>;
}
