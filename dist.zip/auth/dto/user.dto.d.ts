export declare class UserDto {
    userName?: string;
    firstName?: string;
    lastName?: string;
    otherName?: string;
    email?: string;
    mobile?: string;
    status?: string;
    readonly password?: string;
    role?: string;
    gravatar?: string;
    photo?: string;
}
