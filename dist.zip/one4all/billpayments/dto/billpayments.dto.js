"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BillpaymentDto = void 0;
class BillpaymentDto {
}
exports.BillpaymentDto = BillpaymentDto;
//# sourceMappingURL=billpayments.dto.js.map