import { HttpService } from '@nestjs/axios';
import { SmsDto } from './dto/sms.dto';
import { SmsService } from './sms.service';
export declare class SmsController {
    private smsService;
    private httpService;
    private logger;
    constructor(smsService: SmsService, httpService: HttpService);
    sendSms(transDto: SmsDto): Promise<import("rxjs").Observable<import("axios").AxiosResponse<SmsDto, any>>>;
    sendBulkSms(transDto: SmsDto): Promise<any>;
}
