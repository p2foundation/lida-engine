export declare class MobilemoneyModule {
}
