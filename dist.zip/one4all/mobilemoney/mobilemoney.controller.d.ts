import { ReceiveMoneyDto } from './dto/receive.money.dto';
import { MobilemoneyService } from './mobilemoney.service';
export declare class MobilemoneyController {
    private mobilemoneyService;
    private logger;
    constructor(mobilemoneyService: MobilemoneyService);
    debitWallet(transDto: ReceiveMoneyDto): Promise<any>;
}
