export declare class TransStatusDto {
    transReference: string;
    transId?: string;
}
