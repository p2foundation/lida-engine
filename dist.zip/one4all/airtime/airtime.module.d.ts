export declare class AirtimeModule {
}
