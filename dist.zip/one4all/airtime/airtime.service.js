"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AirtimeService = void 0;
const axios_1 = require("@nestjs/axios");
const common_1 = require("@nestjs/common");
const operators_1 = require("rxjs/operators");
const https = require("https");
const constants_1 = require("../../constants");
const utils_1 = require("../../utilities/utils");
let AirtimeService = class AirtimeService {
    constructor(httpService) {
        this.httpService = httpService;
        this.logger = new common_1.Logger('AirtimeService');
        this.AirBaseUrl = constants_1.ONE4ALL_BASEURL;
    }
    transactionStatus(transDto) {
        const { transReference } = transDto;
        const payload = {
            trxn: transReference || ''
        };
        const tsUrl = this.AirBaseUrl + `/TopUpApi/transactionStatus?trxn=${payload.trxn}`;
        const configs = {
            url: tsUrl,
            headers: { ApiKey: constants_1.ONE4ALL_APIKEY, ApiSecret: constants_1.ONE4ALL_APISECRET },
            agent: new https.Agent({
                rejectUnauthorized: false,
            })
        };
        this.logger.log(`transaction status payload == ${JSON.stringify(configs)}`);
        return this.httpService.get(configs.url, { httpsAgent: configs.agent, headers: configs.headers })
            .pipe((0, operators_1.map)(tsRes => {
            this.logger.log(`Query TRANSACTION STATUS response ++++ ${JSON.stringify(tsRes)}`);
            return tsRes.data;
        }), (0, operators_1.catchError)((tsError) => {
            this.logger.error(`Query TRANSACTION STATUS ERROR response ---- ${JSON.stringify(tsError.data)}`);
            return tsError.data;
        }));
    }
    topupAirtime(transDto) {
        const { retailer, recipientNumber, amount, network } = transDto;
        const taParams = {
            retailer: retailer || constants_1.ONE4ALL_RETAILER,
            network: network || 0,
            recipient: recipientNumber || '',
            amount: amount || '',
            trxn: (0, utils_1.generateTransactionId)() || ''
        };
        const newTaParams = JSON.stringify(taParams);
        const taUrl = `/TopUpApi/airtime?retailer=${taParams.retailer}&recipient=${taParams.recipient}&amount=${taParams.amount}&network=${taParams.network}&trxn=${taParams.trxn}`;
        const configs = {
            url: this.AirBaseUrl + taUrl,
            headers: { ApiKey: constants_1.ONE4ALL_APIKEY, ApiSecret: constants_1.ONE4ALL_APISECRET },
            agent: new https.Agent({
                rejectUnauthorized: false,
            }),
        };
        this.logger.log(`Airtime topup payload == ${JSON.stringify(configs)}`);
        return this.httpService.get(configs.url, { httpsAgent: configs.agent, headers: configs.headers })
            .pipe((0, operators_1.map)(taRes => {
            this.logger.verbose(`AIRTIME TOPUP response ++++ ${JSON.stringify(taRes.data)}`);
            return taRes.data;
        }), (0, operators_1.catchError)((taError) => {
            this.logger.error(`AIRTIME TOPUP ERROR response ---- ${JSON.stringify(taError.data)}`);
            return taError.data;
        }));
    }
};
AirtimeService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [axios_1.HttpService])
], AirtimeService);
exports.AirtimeService = AirtimeService;
//# sourceMappingURL=airtime.service.js.map