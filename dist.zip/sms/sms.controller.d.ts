import { SmsService } from './sms.service';
export declare class SmsController {
    private smsService;
    private logger;
    constructor(smsService: SmsService);
}
