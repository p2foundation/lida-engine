"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const helmet_1 = require("helmet");
const app_module_1 = require("./app.module");
const constants_1 = require("./constants");
const fallback_filter_1 = require("./filters/fallback.filter");
const http_filter_1 = require("./filters/http.filter");
const validation_exception_1 = require("./filters/validation.exception");
async function bootstrap() {
    const logger = new common_1.Logger('bootstrap');
    const app = await core_1.NestFactory.create(app_module_1.AppModule);
    app.enableCors();
    app.use((0, helmet_1.default)());
    app.useGlobalFilters(new fallback_filter_1.FallbackExceptionFilter(), new http_filter_1.HttpExceptionFilter());
    app.useGlobalPipes(new common_1.ValidationPipe({
        skipMissingProperties: true,
        exceptionFactory: (errors) => {
            const messages = errors.map((error) => `${error.property} has wrong value ${error.value},
                ${Object.values(error.constraints).join(', ')} `);
            return new validation_exception_1.ValidationException(messages);
        },
    }));
    const port = process.env.PORT || constants_1.SERVER_PORT;
    await app.listen(port);
    logger.debug(`Application listening on port ${port}`);
}
bootstrap();
//# sourceMappingURL=main.js.map