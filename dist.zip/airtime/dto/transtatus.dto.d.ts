export declare class TransStatusDto {
    clientReference: string;
}
