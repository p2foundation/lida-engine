export declare function generateMerchantKey(): string;
export declare function psRandomGeneratedNumber(): string;
