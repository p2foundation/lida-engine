"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateTransactionIdPayswitch = exports.generateTransactionId = exports.generateMerchantKey = void 0;
const common_1 = require("@nestjs/common");
const constants_1 = require("../constants");
function generateMerchantKey() {
    const logger = new common_1.Logger();
    const merchantId = constants_1.PAYSWITCH_USERNAME_PROD;
    const merchantToken = constants_1.PAYSWITCH_APIKEY_PROD;
    const encodedAuth = '' + Buffer.from(merchantId + ':' + merchantToken).toString('base64');
    logger.log('encoded string toBase64 Auth ===>');
    logger.debug(encodedAuth);
    return encodedAuth;
}
exports.generateMerchantKey = generateMerchantKey;
function generateTransactionId() {
    const logger = new common_1.Logger();
    let text = '';
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const date = new Date();
    const day = (date.getDate() < 10 ? '0' : '') + date.getDate();
    const month = (date.getMonth() + 1 < 10 ? '0' : '') + (date.getMonth() + 1);
    const year = date.getFullYear().toString().substr(2, 2);
    const customDate = '' + month + day + year;
    for (let i = 0; i < 6; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    const transId = text + customDate;
    return transId;
}
exports.generateTransactionId = generateTransactionId;
function generateTransactionIdPayswitch() {
    const logger = new common_1.Logger();
    let text = '';
    const possible = '0123456789';
    const date = new Date();
    const day = (date.getDate() < 10 ? '0' : '') + date.getDate();
    const month = (date.getMonth() + 1 < 10 ? '0' : '') + (date.getMonth() + 1);
    const year = date.getFullYear().toString().substr(2, 2);
    const customDate = '' + month + day + year;
    for (let i = 0; i < 6; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    const transId = text + customDate;
    return transId;
}
exports.generateTransactionIdPayswitch = generateTransactionIdPayswitch;
//# sourceMappingURL=utils.js.map